package naointendorip.example.naointendorip;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NaointendoripApplicationTests {

	@Test
	void contextLoads() {
	}

}
