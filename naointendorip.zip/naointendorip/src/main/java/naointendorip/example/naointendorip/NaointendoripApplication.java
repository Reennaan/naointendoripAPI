package naointendorip.example.naointendorip;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NaointendoripApplication {

	public static void main(String[] args) {
		SpringApplication.run(NaointendoripApplication.class, args);
	}

}
